from models.model import EfficientCapsNet, CapsNet

